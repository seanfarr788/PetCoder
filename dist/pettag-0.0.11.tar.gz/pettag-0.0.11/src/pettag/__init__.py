#from .lite import Anonymiser
from .predict import DiseaseCoder

__all__ = ["DiseaseCoder"]